package com.mycompany.loginregsystem;

import javax.swing.JOptionPane;

public class LoginRegSystem {

    public static boolean checkUserName(String Username) {
  return Username.contains("_") && Username.length() > 0 && Username.length() <= 5;
    
    }
    
    public static boolean checkPassword(String password) {    
  return password.matches("^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$");
    }
     
  public static String registerUser(String Username,String password,String name,String surname){
     if (!checkUserName(Username)) {
         return "Username is not correctly formatted,please ensure that your username contains an underscore amd is no more than 5 characters";
     }
     
     if (!checkPassword(password))  {
         return "Password is not correctly formatted,please ensure that the password contains at least 8 characters,a capital letter,a number and a special character.";
     }
     return"Username successfully captured\nPassword succesfully captured\nWelcome " + name + surname;
  }
   public static boolean loginUser(String Username, String password) {
      return checkUserName(Username) && checkPassword(password);
   }
  public static void main(String[]args) {
      String action = JOptionPane.showInputDialog("Are you registering or logging in? (Register/Login)");
      
      if("register".equalsIgnoreCase(action)) {
      String Username = JOptionPane.showInputDialog("Please Enter Username:");
      String password =JOptionPane.showInputDialog("Please Enter password:");
      String name = JOptionPane.showInputDialog("Please Enter your Name:");
      String surname =JOptionPane.showInputDialog("Please enter your Surname:");
      
      String registrationMessage = registerUser(Username,password,name,surname);
      JOptionPane.showMessageDialog(null, registrationMessage);
      }else if ("Login".equalsIgnoreCase(action)) {
          String Username = JOptionPane.showInputDialog("Enter Username");
          String password = JOptionPane.showInputDialog("Enter Password");
          boolean loginSuccess = loginUser(Username, password);
          String loginStatus = loginSuccess ? "Login Successful***" : "Username or password,please try again.";
          JOptionPane.showMessageDialog(null, loginStatus);
      }else{
          JOptionPane.showMessageDialog(null, "Incorrect action.Please enter 'Register' or 'Login'."); 
                  
      }
  }
}
